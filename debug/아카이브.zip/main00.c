/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jseo <jseo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/26 18:07:59 by jseo              #+#    #+#             */
/*   Updated: 2020/10/27 09:34:22 by jseo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "c00.h"
#include "ftstring.h"

int		main(void)
{
	//ft_putchar('1');
	
	//ft_print_alphabet();
	
	//ft_print_reverse_alphabet();
	
	//ft_print_numbers();
	
	//ft_is_negative(-42);
	//t_is_negative(42);
	
	//ft_print_comb();
	
	//ft_print_comb2();
	
	//ft_putnbr(42);
	//ft_putnbr(-42);
	//ft_putnbr(-2147483648);
	
	//ft_print_combn(3);
	//ft_print_combn(7);
	//ft_print_combn(9);
	
	return (0);
}
