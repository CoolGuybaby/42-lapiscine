/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jseo <jseo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/26 18:10:27 by jseo              #+#    #+#             */
/*   Updated: 2020/10/27 09:34:14 by jseo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "c01.h"
#include "ftstring.h"

int		main(void)
{
	//int n1;
	//int *p1 = &n1;
	//ft_ft(p1);
	//ft_putchar(*p1 / 10 + 48);
	//ft_putchar(*p1 % 10 + 48);
	
	//int n2;
	//int *p2_1 = &n2;
	//int **p2_2 = &p2_1;
	//int ***p2_3 = &p2_2;
	//int ****p2_4 = &p2_3;
	//int *****p2_5 = &p2_4;
	//int ******p2_6 = &p2_5;
	//int *******p2_7 = &p2_6;
	//int ********p2_8 = &p2_7;
	//int *********p2_9 = &p2_8;
	
	//ft_ultimate_ft(p2_9);
	//ft_putchar(*********p2_9 / 10 + 48);
	//ft_putchar(*********p2_9 % 10 + 48);
	
	//int a = 2;
	//int b = 1;
	//ft_swap(&a, &b);
	//ft_putchar(a + 48);
	//ft_putchar(b + 48);
	
	//int d;
	//int m;
	//int *div = &d;
	//int *mod = &m;
	//ft_div_mod(9, 4, div, mod);
	//ft_putchar(d + 48);
	//ft_putchar(m + 48);
	
	//int d = 9;
	//int m = 4;
	//int *div = &d;
	//int *mod = &m;
	//ft_ultimate_div_mod(div, mod);
	//ft_putchar(d + 48);
	//ft_putchar(m + 48);
	
	//char *str = "hi this is jseo";
	//ft_putstr(str);
	
	//int length = ft_strlen("hi jseo");
	//ft_putchar(length + 48);
	
	//int index = -1;
	//int tab[9] = { 1, 2, 3, 4, 9, 8, 7, 6, 5 };
	//ft_rev_int_tab(tab, 9);
	//while (++index < 9)
	//{
		//ft_putchar(tab[index] + 48);
	//}
	
	//int index = -1;
	//int tab[10] = { 10, 3, 1, 4, 2, 9, 8, 7, 6, 5 };
	//ft_sort_int_tab(tab, 10);
	//while (++index < 10)
	//{
		//ft_putnbr(tab[index]);
	//}
	
	return (0);
}
