/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jseo <jseo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/27 13:47:48 by jseo              #+#    #+#             */
/*   Updated: 2020/10/27 15:00:25 by jseo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "c04.h"
#include "ftstring.h"
#include <string.h>
#include <stdio.h>

int	main(void)
{
	//char *str = "This is good to go!\n"; // 20 letters
	//printf("%d\n", ft_strlen(str));

	//char *str = "This is good to go!\n";
	//ft_putstr(str);
	
	printf("%d\n", ft_atoi(" 	+--++---123456789"));

	//ft_putnbr_base(40, "0123456789abcdef");
	
	//printf("%d\n", ft_atoi_base("-+---+ff", "0123456789abcdef"));
	
	return (0);
}
