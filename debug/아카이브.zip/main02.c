/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jseo <jseo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/26 18:12:16 by jseo              #+#    #+#             */
/*   Updated: 2020/10/27 09:34:10 by jseo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "c02.h"
#include "ftstring.h"

int		main(void)
{
	//char preset[12];
	//ft_putstr(ft_strcpy(preset, "Hello World\n");
	
	//char preset[16];
	//ft_putstr(ft_strcpy(preset, "Hellow World\n");
	
	//char *alpha_1 = "Hello";
	//char *alpha_2 = "";
	//char *alpha_3 = "he11o";
	//ft_putchar(ft_str_is_alpha(alpha_1) + 48);
	//ft_putchar(ft_str_is_alpha(alpha_2) + 48);
	//ft_putchar(ft_str_is_alpha(alpha_3) + 48);
	
	//char *numeric_1 = "0";
	//char *numeric_2 = "";
	//char *numeric_3 = "123a3456";
	//ft_putchar(ft_str_is_numeric(numeric_1) + 48);
	//ft_putchar(ft_str_is_numeric(numeric_2) + 48);
	//ft_putchar(ft_str_is_numeric(numeric_3) + 48);
	
	//char *lower_1 = "hi space";
	//char *lower_2 = "nonespace";
	//char *lower_3 = "";
	//char *lower_4 = "hi1234";
	//char *lower_5 = "Hi";
	//ft_putchar(ft_str_is_lowercase(lower_1) + 48);
	//ft_putchar(ft_str_is_lowercase(lower_2) + 48);
	//ft_putchar(ft_str_is_lowercase(lower_3) + 48);
	//ft_putchar(ft_str_is_lowercase(lower_4) + 48);
	//ft_putchar(ft_str_is_lowercase(lower_5) + 48);
	
	//char *upper_1 = "HI SPACAE";
	//char *upper_2 = "NONESPACE";
	//char *upper_3 = "";
	//char *upper_4 = "HI1234";
	//char *upper_5 = "Hi";
	//ft_putchar(ft_str_is_uppercase(upper_1) + 48);
	//ft_putchar(ft_str_is_uppercase(upper_2) + 48);
	//ft_putchar(ft_str_is_uppercase(upper_3) + 48);
	//ft_putchar(ft_str_is_uppercase(upper_4) + 48);
	//ft_putchar(ft_str_is_uppercase(upper_5) + 48);
	
	//char *print_1 = "Hell0";
	//char *print_2 = "hello\7F";
	//ft_putchar(ft_str_is_printable(print_1) + 48);
	//ft_putchar(ft_str_is_printable(print_2) + 48);
	
	//char upcase[7] = "a123fg";
	//char *p = upcase;
	//p = ft_strupcase(p);
	//ft_putstr(p);
	
	//char lowcase[12] =  "ABC3214ggHHH";
	//char *p = lowcase;
	//p = ft_strlowcase(p);
	//ft_putstr(p);
	
	//char capital[100] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	//char *p;
	//p = ft_strcapitalize(capital);
	//write(1, p, 100);
	
	//char lcpy[100];
	//int p;
	//p = strlcpy(lcpy, "abasdf", 4);
	//write(1, lcpy, 10);
	//ft_putchar(p + 48);
	//p = ft_strlcpy(lcpy, "efasdf", 4);
	//write(1, lcpy, 10);
	//ft_putchar(p + 48);
	
	//char hex[100] = "Coucou\ntu vas bien ?";
	//ft_putstr_non_printable(hex);
	
	return (0);
}
